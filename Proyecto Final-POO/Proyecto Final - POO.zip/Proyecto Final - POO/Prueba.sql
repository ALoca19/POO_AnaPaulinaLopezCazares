create database escuela;

use escuela;

CREATE TABLE persona (
idPersona INT NOT NULL AUTO_INCREMENT,
nombre VARCHAR(50) NOT NULL,
domicilio VARCHAR(200) NULL,
celular VARCHAR(10) NULL,
correo_electronico VARCHAR(50) NULL,
fecha_nacimiento DATE NULL,
genero VARCHAR(10) NOT NULL,
PRIMARY KEY(idPersona)
);

select * from persona;

insert into persona(clave, nombre, domicilio, celular, correo_electronico, fecha_nacimiento, genero) values
( 005, "Ana Paulina", "chapultepec","49234398", "anitaynala@hotmail.com", "1999-10-10","femenino");

insert into persona(nombre, domicilio, celular, correo_electronico, fecha_nacimiento, genero) values
("sgra", "asrb","49234398", "anitaynala@hotmail.com", "1999-10-10","femenino");