package Controlador;

import Modelo.Persona;
import Vista.VistaPersona;
import Modelo.consultaPersona;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import javax.swing.JOptionPane;

public class ControladorPersona implements ActionListener{

    private VistaPersona vista;
    private Persona persona;
    private consultaPersona modelo;

    public ControladorPersona(VistaPersona vista, Persona persona, consultaPersona modelo) {
        this.vista = vista;
        this.persona = persona;
        this.modelo = modelo;
        vista.botonInsertar.addActionListener(this);
        vista.botonLimpiar.addActionListener(this);
        vista.botonBuscar.addActionListener(this);
        vista.botonModificar.addActionListener(this);
        vista.botonEliminar.addActionListener(this);
    }
    
    public void iniciar()
    {
        vista.setTitle("Registro");
        vista.setLocationRelativeTo(null);
        vista.cajaID.setVisible(false);
    }
    
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==vista.botonInsertar)
        {
            persona.setClave(vista.cajaClave.getText());
            persona.setNombre(vista.cajaNombre.getText());
            persona.setDomicilio(vista.cajaDomicilio.getText());
            persona.setCelular(vista.cajaCelular.getText());
            persona.setCorreo(vista.cajaCorreo.getText());
            persona.setFecha(Date.valueOf(vista.cajaFecha.getText()));
            persona.setGenero(vista.cajaGenero.getSelectedItem().toString());
        
            if(modelo.insertar(persona))
            {
                JOptionPane.showMessageDialog(null, "Registro insertado correctamente");
                limpiarCajas();
            }
            else
            {
             JOptionPane.showMessageDialog(null, "ERROR al insertar registro");
             limpiarCajas();
            }
        }
        
        if(ae.getSource() == vista.botonLimpiar)
        {
            limpiarCajas();
        }
        
        if(ae.getSource() == vista.botonBuscar)
        {
            persona.setClave(vista.cajaBuscar.getText());
            
            if(modelo.buscar(persona))
            {
                vista.cajaID.setText(String.valueOf(persona.getIdPersona()));
                vista.cajaClave.setText(persona.getClave());
                vista.cajaNombre.setText(persona.getNombre());
                vista.cajaDomicilio.setText(persona.getDomicilio());
                vista.cajaCelular.setText(persona.getCelular());
                vista.cajaCorreo.setText(persona.getCorreo());
                vista.cajaFecha.setText(String.valueOf(persona.getFecha()));
                vista.cajaGenero.setSelectedItem(persona.getGenero());
            }
            else
            {
                JOptionPane.showMessageDialog(null, "No existe una persona con esa clase");
            }
        }
        
        
        if(ae.getSource() == vista.botonModificar)
        {
            persona.setIdPersona(Integer.parseInt(vista.cajaID.getText()));
            persona.setClave(vista.cajaClave.getText());
            persona.setNombre(vista.cajaNombre.getText());
            persona.setDomicilio(vista.cajaDomicilio.getText());
            persona.setCelular(vista.cajaCelular.getText());
            persona.setCorreo(vista.cajaCorreo.getText());
            persona.setFecha(Date.valueOf(vista.cajaFecha.getText()));
            persona.setGenero(vista.cajaGenero.getSelectedItem().toString());
        
            
            if(modelo.modificar(persona))
            {
                JOptionPane.showMessageDialog(null, "Modificado Correctamente");
                limpiarCajas();
            
            }
            else
            {
                JOptionPane.showMessageDialog(null, "No se pudo modificar el registro");
                limpiarCajas();
            }
        }
        
        if(ae.getSource() == vista.botonEliminar)
        {
            persona.setIdPersona(Integer.parseInt(vista.cajaID.getText()));
            
            
            if(modelo.eliminar(persona))
            {
                JOptionPane.showMessageDialog(null, "El registro se elimino Correctamente");
                limpiarCajas();
            
            }
            else
            {
                JOptionPane.showMessageDialog(null, "No se pudo eliminar el registro");
                limpiarCajas();
            }
        }
        
    }
    
    public void limpiarCajas()
    {
        vista.cajaID.setText(null);
        vista.cajaBuscar.setText(null);
        vista.cajaClave.setText(null);
        vista.cajaNombre.setText(null);
        vista.cajaDomicilio.setText(null);
        vista.cajaCelular.setText(null);
        vista.cajaCorreo.setText(null);
        vista.cajaFecha.setText(null);
        vista.cajaGenero.setSelectedIndex(0);
        
    }
}
