package Proyecto;

import Controlador.ControladorPersona;
import Modelo.Persona;
import Modelo.consultaPersona;
import Vista.VistaPersona;

public class Main {
    
    public static void main(String[] args) {
    VistaPersona vista = new VistaPersona();
    Persona persona = new Persona();
    consultaPersona modelo = new consultaPersona();
    ControladorPersona controlador= new ControladorPersona(vista, persona, modelo);
    
    controlador.iniciar();
    vista.setVisible(true);
    }
    
    
}
